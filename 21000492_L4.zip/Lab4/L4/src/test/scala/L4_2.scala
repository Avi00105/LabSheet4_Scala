object L4_2 {

  def  main(args:Array[String]):Unit={

    printf("Input the number : ");

    val x=scala.io.StdIn.readInt();

    x match{

      case x if (x<0)=>printf("Negative number")

      case x if (x==0)=>printf("zero")

      case x if (x%2==0 && x!=0 && x>0)=>printf("even Number")

      case x if (x%2!=0 && x!=0 && x>0)=>printf("Odd NUmber")

    }

  }

}
