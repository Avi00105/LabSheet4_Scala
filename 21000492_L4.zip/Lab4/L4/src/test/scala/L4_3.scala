import java.util.Formatter

object L4_3 {

    def toUpper(s: String): String = {

      return s.toUpperCase()
    }

    def toLower(s: String): String = {

      return s.toLowerCase()

    }

    def formatNames(name: String)(formatter: String => String): String = {

      formatter(name)

    }


  def main(args: Array[String]): Unit = {

    val inputNames = List("Benny", "Niroshan", "Saman", "Kumara")

    for (inputName <- inputNames) {

      val upperOutput = formatNames(inputName)(toUpper)
      val lowerOutput = formatNames(inputName)(toLower)

      println(upperOutput)
      println(lowerOutput)
    }
  }
}

