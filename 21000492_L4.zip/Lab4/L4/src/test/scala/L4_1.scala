
object L4_1 {

  def interest(yearMoney:Int):Double= {

    if (yearMoney == 20000)

      return yearMoney * 2 / 100


    else if (yearMoney == 200000)

      return yearMoney * 4 / 100


    else if (yearMoney == 2000000)

      return yearMoney * 3.5 / 100


    else

      return yearMoney * 6.5 / 100


  }
  def main(args:Array[String]):Unit= {

    printf("Enter the yearMoney Value : ");

    val m = scala.io.StdIn.readInt();

    val interestMoney = interest(m);

    println(s"Interest for $m = $interestMoney");
  }
}
